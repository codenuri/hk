#include <iostream>

void draw_line(int x1, int y1, int x2, int y2) {}

int main()
{
	int x1 = 10, y1 = 10;
	int x2 = 10, y2 = 10;

	draw_line(x1, y1, x2, y2);
}