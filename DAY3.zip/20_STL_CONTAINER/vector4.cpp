#include <iostream>
#include <vector>

int main()
{
	std::vector<int> v(5); // 5개를 0으로

	v.resize(3); // 어떻게 만들었을까요 ?


}
