#include <iostream>

int main()
{
	int* p1 = new int;	
	int* p2 = p1;

	// 사용자가 직접 메모리를 관리할때 문제점
	// #1. 메모리 누수


	// #2. dangling pointer



	// #3. double delete


}