// C 스타일 () 캐스팅의 문제점을 해결하기 위해서
// C++ 에서는 4개의 캐스팅 연산자를 제공

// 1. static_cast 
// 2. reinterpret_cast
// 3. const_cast
// 4. dynamic_cast
