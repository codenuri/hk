﻿// 45page ~
int main()
{
	int n = 0;

	double* p = &n; // ??

	*p = 3.4;
}
